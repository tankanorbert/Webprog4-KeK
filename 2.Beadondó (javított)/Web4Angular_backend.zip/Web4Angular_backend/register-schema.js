const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://asd:Qwer1234*@cluster0-bzcsn.mongodb.net/test');

const UserSchema = require('./schema/user');

module.exports = () => {
  mongoose.model('users', UserSchema);
};