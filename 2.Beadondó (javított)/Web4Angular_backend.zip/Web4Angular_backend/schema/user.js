const Schema = require('mongoose').Schema;
const passportLocalMongoose = require('passport-local-mongoose');

const UserSchema = new Schema({
  token: {
    type: String
  },
  isAdmin: {
    type: Boolean
  },
  username: {
    type: String,
    required: true,
    unique: true
  },
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },    
});

UserSchema.plugin(passportLocalMongoose, {
  usernameLowerCase: true,
});

module.exports = UserSchema;