require('./register-schema.js')();

const express = require('express');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const BearerStrategy = require('passport-http-bearer').Strategy;
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const User = mongoose.model('users');

var users = require('./controller/user.controller');

const app = express();

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false,
}));

app.use(passport.initialize());

passport.use(new LocalStrategy({
  session: false,
}, User.authenticate()));

passport.use(new BearerStrategy(
  (token, done) => {
    User.findOne({
      token,
    }, (err, user) => {
      if (err) {
        return done(err);
      }
      if (!user) {
        return done(null, false);
      }
      return done(null, user, {
        scope: 'all',
      });
    });
  }
));

app.use(express.static(path.join(__dirname, 'dist')));

users(app, passport);


const port = process.env.PORT || '3000';
app.set('port', port);

const server = http.createServer(app);
server.listen(port, () => {
  console.log('API running on localhost:' + port);
});
