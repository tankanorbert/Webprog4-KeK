const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const crypto = require('crypto');

const User = mongoose.model('users');

module.exports = function (app, passport) {
  router.post('/register', (request, response) => {
    crypto.randomBytes(32, function (ex, buf) {
        const token = buf.toString('hex');
        User.register(new User({
          username: request.body.username,
          token: request.body.token,
          isAdmin: false,
          registeredAt: new Date()
        }), request.body.password, (error, user) => {
          if (error) {
              console.error(error);
            response.status(400).send().end();
          } else {
            response.json(user);
          }
        });
      });
    });

  router.post('/login', passport.authenticate('local', {
    session: false
  }), (request, response) => {
    crypto.randomBytes(32, function (ex, buf) {
        const token = buf.toString('hex');
        User.update({
            _id: request.user._id
          }, {
            token: token
          },
          (error, affected) => {
            if (error) {
                console.error(error);
              response.status(400).end();
            } else {
              request.user.token = token;
              response.json(request.user);
            }
          });
      });
  });

  router.get('/logout', function (req, res) {
    res.status(200).send().end();
  });

  app.use("/users", router);
};
